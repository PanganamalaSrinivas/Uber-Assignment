#Libraries
library(stringr)
library(ggplot2)
library(tidyr)
library(dplyr)
library(sqldf)
#Import the uber data file
uber <- read.csv("Uber Request Data.csv", stringsAsFactors = F)
#uber <- uber[which(-is.na(uber$Request.timestamp) == T)]
uber
#Deduplicating the data and cleaning it
#Request id
duplicated(uber$Request.id)
ndup <- sum(duplicated(uber$Request.id))
ndup #There are no duplicates
#Testing for NAs 11912 NAs
n_NAS <- sum(is.na(uber))
n_NAS #6564


#Request id

uber <- uber[!(uber$Request.id == "" |is.na(uber$Request.id)),]
n1 <- sum(is.na(uber$Request.id))
n1 #Reads zero which means that NAs are removed
nrow(uber)
#Pickup.point Nas and blanks are removed
uber <- uber[!(uber$Pickup.point == "" |is.na(uber$Pickup.point)),]
n2 <- sum(is.na(uber$Pickup.point))               
n2 #Reads zero so NAs are removed
nrow(uber)
#6745 rows

n3 <- sum(is.na(uber$Driver.id))
n3 #2650 Driver Ids are NAs
#Assumption: These are not removed as they impact the supply and Demand figures

#Status
uber <- uber[!(uber$Status == ""|is.na(uber$Status)),]
n4 <- sum(is.na(uber$Status))
n4 #Reads zero so status NAs are removed
nrow(uber) #6745 rows
#Request.timestamp

uber <- uber[!(uber$Request.timestamp == ""|is.na(uber$Request.timestamp)),]
n5 <- sum(is.na(uber$Request.timestamp))
n5
#Zero rows are NA

#######################################################################
#NAs of Request Timestamp and Drop Timestamp cannot be removed as they affect the Supply and Demand calculations
#So we assume that these NAs have to be ignored and not imputed!

######################################################################################
#Demand calculation

#Creare basic dfs for gap and no car available
uber_sup <- uber
uber_no_car <- uber
uber_gap <- uber
uber_cancellations <- uber

uber$Demand <- nrow(uber)
uber$Demand

#Supply calculation
#uber$Supply

#Count of cancellations
len_cancelled <- sum(str_count(uber$Status,"Cancelled"))
len_cancelled

#Count of NO Cars Available
len_NCA <- sum(str_count(uber$Status,"No Cars Available"))
len_NCA
#Totla of Cars not available or cancelled
len <- len_NCA + len_cancelled
len
#Assign no. of cars cancelled or not available to no_cars
uber_no_car$no_cars <- len
uber_no_car$no_cars

nrow(uber)

#Supply assignment
uber_sup$Supply <- nrow(uber) - len
uber_sup$Supply

######################################################
################################################

#Extract Date-time fields

#Format request timestamp
uber$Request.timestamp <- as.POSIXlt(format(uber$Request.timestamp,"%d%m%Y %H:%M:%S"), format = "%m-%d-%Y %H")
uber$Request.timestamp
#uber$req_hour <- format(uber$Request.timestamp,"%H")
#Separate into date and time
dtparts = t(as.data.frame(strsplit(uber$Request.timestamp,' ')))
row.names(dtparts) = NULL
dat <- dtparts[,1]
tim <- dtparts[,2]
tim

#uber$req_hour <- format(tim,"%H")
#uber$req_hour <- as.POSIXlt(format(uber$Request.timestamp,"%d%m%Y%H:%M"), format = "%H")
#Extract request hour
uber$req_hour <- format(strptime(tim,"%H:%M:%S"),'%H')
uber$req_hour
#Assign request data
uber$req_date <- dat

uber$req_hour
uber$req_date
uber
#Assign time slots
#The timeslots factor out the day into intervals ranging from Ealy Morning Morning,Aternoon, Evening, Night to Late Night. This helps to
#relate Demand to a specific period of the day
uber$req_hour <- as.numeric(uber$req_hour)
uber$timeslot <- ifelse(uber$req_hour >= 1 & uber$req_hour <= 5,"Early Morning",ifelse(uber$req_hour > 5 & uber$req_hour <= 12,"Morning",ifelse(uber$req_hour > 12 & uber$req_hour <= 15,"Afternoon",ifelse(uber$req_hour > 15 & uber$req_hour <= 19,"Evening",ifelse(uber$req_hour > 19 & uber$req_hour <= 21,"Night","Late Night")))))
#uber$timeslot <- ifelse(uber$req_hour > 5 & uber$req_hour <= 11,"Morning","Rest")
uber$timeslot
#Write to csv file for Tableau plot
write.csv(uber,"uber.csv")

#Univariate Analysis of Demand Mean
mean_Demand <- mean(uber$Demand, na.rm=T)
mean_Demand #Mean is 6745;Median is also 6745
med_Demand <- median(uber$Demand)
med_Demand # 6745
table(uber$req_date)


#Univariate Analysis of Demand segmented analysis
#Plotting the Histogram Demand over timeslots.The histogram plots the frequencies of Demand
#over timeslots. The aesthetics uses the timeslot. Position dodge is used to separate out the values.
ggplot(uber, aes(timeslot)) + geom_histogram(stat = "count",position = "dodge")

#Plotting the Histogram Demand over PickupPoints
#The histogram plots the frequencies of Demand over Pickup-Points. Aesthetics is Pickp-Point on the x axis.
#facet_wrap captures the information for the Timelsots in different frames.
ggplot(uber, aes(uber$Pickup.point)) + geom_histogram(stat = "count",position = "dodge") + facet_wrap(~timeslot)

#ggplot(uber$Pickup.point~uber$timeslot, aes(uber$Pickup.point)) + geom_histogram(stat = "count",position = "dodge")

#Assigning Supply data fields of the df
#Formatting drop timestamp
uber_sup$Drop.timestamp <- as.POSIXlt(format(uber$Drop.timestamp,"%d%m%Y %H:%M:%S"), format = "%m-%d-%Y %H")
uber_sup$Drop.timestamp

mean_Supply <- mean(uber_sup$Supply, na.rm=T)
mean_Supply # 2831
med_Supply <- median(uber_sup$Supply)
med_Supply # 2831


#split the date-time into date and time
dtparts_sup = t(as.data.frame(strsplit(uber_sup$Drop.timestamp,' ')))
row.names(dtparts_sup) = NULL
dat_s <- dtparts_sup[,1]
tim_s <- dtparts_sup[,2]
tim_s
dat_s
#Extract drop_hour and drop date
uber_sup$drop_hour <- format(strptime(tim_s,"%H:%M:%S"),'%H')
uber_sup$drop_hour
uber_sup$drop_date <- dat_s
uber_sup$drop_date
#assign to time slots for drop hours
uber_sup$drop_hour <- as.numeric(uber_sup$drop_hour)
uber_sup$timeslot_drop <- ifelse(uber_sup$drop_hour >= 1 & uber_sup$drop_hour <= 5,"Early Morning",ifelse(uber_sup$drop_hour > 5 & uber_sup$drop_hour <= 12,"Morning",ifelse(uber_sup$drop_hour > 12 & uber_sup$drop_hour <= 15,"Afternoon",ifelse(uber_sup$drop_hour > 15 & uber_sup$drop_hour <= 19,"Evening",ifelse(uber_sup$drop_hour > 19 & uber_sup$drop_hour <= 21,"Night","Late Night")))))
#uber$timeslot <- ifelse(uber$req_hour > 5 & uber$req_hour <= 11,"Morning","Rest")
uber_sup$timeslot_drop
write.csv(uber_sup,"uber_sup.csv")

#Univariate and segmented analysis of SUpply
#Plotting the Histogram Supply over timeslots. The reason for the Histogram is it plots the Count of Supply
#Over the timelslots. Position dodge separates the values.

ggplot(uber_sup, aes(timeslot_drop)) + geom_histogram(stat = "count",position = "dodge")

#Plotting the Histogram supply over PickupPoints and facet wrapped to include timeslots
#The reason for the Histogram is it plots the Count of Supply by Pickup-Point (aesthetic for x axis)
#Facet wrap captures the Timeslot Frames in separate frames.
ggplot(uber_sup, aes(uber_sup$Pickup.point)) + geom_histogram(stat = "count",position = "dodge")+facet_wrap(~timeslot_drop)
 

#Assigning fields to df uber_no_car
uber_no_car$Request.timestamp <- as.POSIXlt(format(uber$Request.timestamp,"%d%m%Y %H:%M:%S"), format = "%m-%d-%Y %H")
uber_no_car$Request.timestamp
#uber$req_hour <- format(uber$Request.timestamp,"%H")
#Separate into date and time
dtparts = t(as.data.frame(strsplit(uber_no_car$Request.timestamp,' ')))
row.names(dtparts) = NULL
dat <- dtparts[,1]
dat
tim <- dtparts[,2]
tim

#uber$req_hour <- format(tim,"%H")

#uber$req_hour <- as.POSIXlt(format(uber$Request.timestamp,"%d%m%Y%H:%M"), format = "%H")
#Assignig fields to the df uber_no_car cancelled or not available
#Assigning request hour
uber_no_car$req_hour <- format(strptime(tim,"%H:%M:%S"),'%H')
uber_no_car$req_hour
#Assigning request data
uber_no_car$req_date <- dat
uber_no_car$req_date
#Typecasting as numeric
uber_no_car$req_hour <- as.numeric(uber_no_car$req_hour)
#Assigning timeslots by the period of the day or night. It factors the day into periods over whcih analysis can be
#related to specific periods of the day

uber_no_car$timeslot_nocar <- ifelse(uber_no_car$req_hour >= 1 & uber_no_car$req_hour <= 5,"Early Morning",ifelse(uber_no_car$req_hour > 5 & uber_no_car$req_hour <= 12,"Morning",ifelse(uber_no_car$req_hour > 12 & uber_no_car$req_hour <= 15,"Afternoon",ifelse(uber_no_car$req_hour > 15 & uber_no_car$req_hour <= 19,"Evening",ifelse(uber_no_car$req_hour > 19 & uber_no_car$req_hour <= 21,"Night","Late Night")))))
#uber$timeslot <- ifelse(uber$req_hour > 5 & uber$req_hour <= 11,"Morning","Rest")
uber_no_car$timeslot_nocar
#Write to Tableau csv file for plot
write.csv(uber_no_car,"uber_No_Car.csv")


#Plotting the Histogram No cars available or cancelled over timeslots
#The reason for the Histogram is that it plots frequences of No cars available or cancelled
#timeslots of the day. Position dodge separates the values

ggplot(uber_no_car, aes(timeslot_nocar)) + geom_histogram(stat = "count",position = "dodge")

#
#Plotting the Histogram No cars available or cancelled over PickupPoints 
#The Histogtam is used because it plots the frequences of the Cars not available or cancelled
#over Pickup-Points and facet wrap arranges the timeslot in frames

ggplot(uber_no_car, aes(uber_no_car$Pickup.point)) + geom_histogram(stat = "count",position = "dodge")+facet_wrap(~timeslot_nocar)

#Assigning fields to df ubder_gap

uber_gap$Request.timestamp <- as.POSIXlt(format(uber_gap$Request.timestamp,"%d%m%Y %H:%M:%S"), format = "%m-%d-%Y %H")
uber_gap$Request.timestamp
#uber$req_hour <- format(uber$Request.timestamp,"%H")
#Separate into date and time
dtparts = t(as.data.frame(strsplit(uber_gap$Request.timestamp,' ')))
row.names(dtparts) = NULL
dat <- dtparts[,1]
dat
tim <- dtparts[,2]
tim

#uber$req_hour <- format(tim,"%H")

#uber$req_hour <- as.POSIXlt(format(uber$Request.timestamp,"%d%m%Y%H:%M"), format = "%H")
#Assigning request hour
uber_gap$req_hour <- format(strptime(tim,"%H:%M:%S"),'%H')
uber_gap$req_hour
#Assigning request data
uber_gap$req_date <- dat
uber_gap$req_date
#Assigning timeslots
uber_gap$req_hour <- as.numeric(uber_gap$req_hour)
#Timeslots factor the day into periods over which analysis can be period specific
uber_gap$timeslot_gap <- ifelse(uber_gap$req_hour >= 1 & uber_gap$req_hour <= 5,"Early Morning",ifelse(uber_gap$req_hour > 5 & uber_gap$req_hour <= 12,"Morning",ifelse(uber_gap$req_hour > 12 & uber_gap$req_hour <= 15,"Afternoon",ifelse(uber_gap$req_hour > 15 & uber_gap$req_hour <= 19,"Evening",ifelse(uber_gap$req_hour > 19 & uber_gap$req_hour <= 21,"Night","Late Night")))))

#uber$timeslot <- ifelse(uber$req_hour > 5 & uber$req_hour <= 11,"Morning","Rest")
uber_gap$timeslot_gap
#Gap between demand and supply assignment
uber_gap$gap <- uber$Demand - uber_sup$Supply
uber_gap$gap
#Write to csv for Tableau Plot
write.csv(uber_gap,"uber_gap.csv")

#Plotting the Histogram gap over frquency of gap
#The Histogram plots the count of the Gap over the timeslot whcih is the x aesthetic
#Position dodge separates the values
ggplot(uber_gap, aes(timeslot_gap)) + geom_histogram(stat = "count",position = "dodge")

#The histogram plots the count of gap between demand and supply
#Plotting the Histogram gap over PickupPoints and facet wrapped to include frames for the timeslots
ggplot(uber_gap, aes(uber_gap$Pickup.point)) + geom_histogram(stat = "count",position = "dodge")+facet_wrap(~timeslot_gap)


#Metrics
#Completed by Request Ratio
#no of request to airport/no of requests
 #not canclled and not not available.packages(
   
 #Completed_BY_Req_Ratio  to airport 
len_NCA_to_airport <- sum(str_count(uber$Status[which(uber$Pickup.point == "City")],"No Cars Available"))
len_NCA_to_airport

len_Cancelled_To_airport <- sum(str_count(uber$Status[which(uber$Pickup.point == "City")],"Cancelled"))
len_Cancelled_To_airport

num_No_cars_To_airport <- len_NCA_to_airport + len_Cancelled_To_airport
num_No_cars_To_airport

num_Completed_by_Request <- length(uber$Request.id[which(uber$Pickup.point == "City")]) - num_No_cars_To_airport
num_Completed_by_Request

num_request_to_airport <- length(uber$Request.id[which(uber$Pickup.point == "City")])
num_request_to_airport

Completed_BY_Req_Ratio <- round(num_Completed_by_Request/num_request_to_airport,2)
Completed_BY_Req_Ratio #0.43 
#########################################################################################
#Completed_BY_Req_Ratio  to city

len_NCA_to_city <- sum(str_count(uber$Status[which(uber$Pickup.point == "Airport")],"No Cars Available"))
len_NCA_to_city

len_Cancelled_To_city <- sum(str_count(uber$Status[which(uber$Pickup.point == "Airport")],"Cancelled"))
len_Cancelled_To_city

num_No_cars_To_city <- len_NCA_to_city + len_Cancelled_To_city
num_No_cars_To_city

num_Completed_by_Request_to_city <- length(uber$Request.id[which(uber$Pickup.point == "Airport")]) - num_No_cars_To_city
num_Completed_by_Request_to_city

num_request_to_city <- length(uber$Request.id[which(uber$Pickup.point == "Airport")])
num_request_to_city

Completed_BY_Req_Ratio_to_city <- round(num_Completed_by_Request_to_city/num_request_to_city,2)
Completed_BY_Req_Ratio_to_city #0.41
#########################################################################################
#Cancellation Ratio to airport

len_Cancelled_To_airport <- sum(str_count(uber$Status[which(uber$Pickup.point == "City")],"Cancelled"))
len_Cancelled_To_airport

num_request_to_airport <- length(uber$Request.id[which(uber$Pickup.point == "City")])
num_request_to_airport

cancellation_ratio <- round(len_Cancelled_To_airport/num_request_to_airport,2)
cancellation_ratio #0.3

#Format timestamp
uber_cancellations$Request.timestamp <- as.POSIXlt(format(uber_cancellations$Request.timestamp,"%d%m%Y %H:%M:%S"), format = "%m-%d-%Y %H")
uber_cancellations$Request.timestamp
#uber$req_hour <- format(uber$Request.timestamp,"%H")
#Separate into date and time
dtparts = t(as.data.frame(strsplit(uber_cancellations$Request.timestamp,' ')))
row.names(dtparts) = NULL
dat <- dtparts[,1]
dat
tim2 <- dtparts[,2]
tim2

#uber$req_hour <- format(tim,"%H")

#uber$req_hour <- as.POSIXlt(format(uber$Request.timestamp,"%d%m%Y%H:%M"), format = "%H")
#Assigning fields to cancellations df
uber_cancellations$req_hour <- format(strptime(tim2,"%H:%M:%S"),'%H')
uber_cancellations$req_hour
uber_cancellations$req_date <- dat
uber_cancellations$req_date

uber_cancellations$req_hour <- as.numeric(uber_gap$req_hour)
uber_cancellations$cancellations <- len_Cancelled_To_airport
#Plot of req_hour vs count of cancellations
#The reason for the hisotgram is it plots the count of cancellations over request hour
#Aesthetic is request hour on the x axis; position dodge separates the values
ggplot(uber_cancellations, aes(req_hour)) + geom_histogram(stat = "count",position = "dodge")


#######################################################################################
#Inflow of cars going to airport

Inflow <- length(uber$Request.id[which(uber$Pickup.point == "City")]) - num_No_cars_To_airport
Inflow

#Outflow of cars leaving the airport

Outflow <- length(uber$Request.id[which(uber$Pickup.point == "Airport")]) - num_No_cars_To_city
Outflow
###############################################################################################

#Idletime Assignments
#Assign Drop.timestamp
uber_idletime_req$Drop.timestamp <- uber$Drop.timestamp
uber_idletime_req$Drop.timestamp

#Separate into date and time
dtparts = t(as.data.frame(strsplit(uber_idletime_req$Drop.timestamp,' ')))
row.names(dtparts) = NULL
dat <- dtparts[,1]
dat
#Assign time drop 
tim_drop <- dtparts[,2]
tim_drop
uber_idletime_req$time_drop <- tim_drop


#Arrange in ascending order (by default) of request timestamp for idletime calculation
uber_idletime_req <- arrange(uber, uber$Request.timestamp)
#uber_idletime_drop <- arrange(uber, desc(uber$Request.timestamp))

nrow(uber_idletime_req)
#Format request time


#Format and Extract drop_hour field in Hours
uber_idletime_req$drop_hour <- format(strptime(tim_drop,"%H:%M:%S"),'%H')
uber_idletime_req$drop_hour

uber_idletime_req$time_drop <- strptime(tim_drop,"%H:%M:%S")


nrow(uber_idletime_req)

#print(uber_idletime_req$Request.timestamp[i])

uber_idletime_req$time_drop <-  strptime(tim_drop,"%H:%M:%S")
uber_idletime_req$time_drop

dtparts2 <- t(as.data.frame(strsplit(uber_idletime_req$Request.timestamp,' ')))
row.names(dtparts2) = NULL
dat2 <- dtparts2[,1]
dat2
#Assign request time  
time <- dtparts2[,2]
time
uber_idletime_req$time <- time
uber_idletime_req$time <- strptime(time,"%H:%M:%S")
uber_idletime_req$time


for(i in seq(from=1,to=nrow(uber_idletime_req), by= 1)){
  
    
  for(j in seq(from=1, to=nrow(uber_idletime_req), by= 1)) 
  {
    
    
    ifelse(is.na(uber_idletime_req$Driver.id[i] == T),break,0)
    ifelse(is.na(uber_idletime_req$Driver.id[j] == T),break,0)
    ifelse(uber_idletime_req$Driver.id[i] == uber_idletime_req$Driver.id[j],t <- j,t <- 0)
    ifelse(uber_idletime_req$Pickup.point[j] == "Airport",t <- j,t <- 0)
    
    
    if ( t > 0){
      t <- 0
      #Reset t to zero so it can work again the next iteration
      #print (t)
      
      
      #Assign idletime
      uber_idletime_req$idletime[i] <- difftime(uber_idletime_req$time[j],uber_idletime_req$time_drop[i], units=c("hours"))
      #Diff time subtracts drop time from Request time to arrive at the idletime.
     }
    
   
    next
  }
}  
uber_idletime_req$idletime



#Assign hrs_idletime for ggplot for a Bar Chart
hrs_idletime <- data.frame(aggregate(idletime~req_hour,uber_idletime_req, sum))

hrs_idletime


#Plot the bar Chart This Plots Idletime versus request hour
ggplot(hrs_idletime, aes(req_hour,idletime))+geom_bar(stat="identity")

#Write to csv for Tableau plot
write.csv(hrs_idletime,"idle_timeIII.csv")